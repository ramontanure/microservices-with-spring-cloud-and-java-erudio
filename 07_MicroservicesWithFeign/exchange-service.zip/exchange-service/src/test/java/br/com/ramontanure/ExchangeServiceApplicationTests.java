package br.com.ramontanure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExchangeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
